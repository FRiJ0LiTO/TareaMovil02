//
//  TareaMovil02App.swift
//  TareaMovil02
//
//  Created by Alumno on 27/09/23.
//

import SwiftUI

@main
struct TareaMovil02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
