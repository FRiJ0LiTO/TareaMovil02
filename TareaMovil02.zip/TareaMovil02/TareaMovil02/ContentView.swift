//
//  ContentView.swift
//  TareaMovil02
//
//  Created by Alumno on 27/09/23.


import SwiftUI

extension Color {
    init(hex: UInt32, alpha: Double = 1.0) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255.0,
            green: Double((hex >> 8) & 0xFF) / 255.0,
            blue: Double(hex & 0xFF) / 255.0,
            opacity: alpha
        )
    }
}
extension Color {
    static let customBlue = Color(hex: 0x82A0D8)
    static let customRed = Color(hex:0xf22b56)
    static let customYellow = Color(hex: 0xEBEBAB)
    static let customGreen = Color(hex: 0x4d8f81)
    static let customBrowm = Color(hex:0x9b4b54)
}

struct ContentView: View {
    
    @State private var mensaje: String = ""
    @State private var showMensaje: Bool = false
    @State private var totalCuenta: Double = 0.0
    @State private var numPersonas: Double = 0.0
    @State private var totalPersona: String = ""
    @State private var resultado: Double = 0.0
    @State private var sliderValor = 10.0
    @State private var textSlider: Int = 0
    @State private var isEditing = false
    @State private var isRedondeo = false
    @State private var cantidadTotal = 0.0
    @State private var  totalInt = 0
    
    var body: some View {
        Color.customYellow
                    .edgesIgnoringSafeArea(.all)
                    .overlay(
        VStack {
            
            Text("Calculadora de pago con propina")
                .padding(10)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.customRed)
                .multilineTextAlignment(.center)
        
            Spacer()
            
            HStack() {
                Text("Total de la Cuenta:")
                Spacer()
                TextField("10019", value:$totalCuenta, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 150)
            }
            
            .padding(10)
            
            HStack() {
                Text("Número de Personas:")
                Spacer()
                TextField("", value:$numPersonas, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 150)
            }
            
            .padding(10)
            
            HStack() {
                Text("Propina:")
                Spacer()
                Slider(value: $sliderValor, in: 0 ... 100, step: 5,
                       onEditingChanged: { editing in
                        isEditing = editing
                })
                .tint(.red)
                Text("\(Int(sliderValor)) %")
            }
            
            .padding(10)
            
            HStack(){
                Text("Redondear decimales:")
                Spacer()
                Toggle("", isOn: $isRedondeo)
                    .tint(.customBrowm)
            }
            
            .padding(10)
            HStack() {
                Text("Total por persona:")
                Spacer()
                Text("\(mensaje)")
                    .font(.title)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.leading)
            }
            .padding(10)
            
            Button("Calcular", action: creaMensaje)
            
            //Modificador de boton
                .buttonStyle(.borderedProminent)
                .buttonStyle(.plain)
                .background(Color.green)
                .tint(Color.customGreen)
                .cornerRadius(23)
                .alert("Los primeros dos campos deben estar completos", isPresented: $showMensaje) {
                    Button("Ok"){}
                }
                .padding(20)
            
            VStack {
                Image("Propina")
                    .resizable(resizingMode: .stretch)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200.0)
                Spacer()
                Text("App creada por: Jaime Cabrera Flores | A00835376")
                    .font(.subheadline)
                    .fontWeight(.regular)
                    .foregroundColor(.customBrowm)
            }
        } .background(Color.customYellow)
        
        
        
        .padding()
        .background(Color.customYellow)
        )
    }
    
    func creaMensaje(){
        
        resultado = calcularPropina(personas: numPersonas, cuenta: totalCuenta, prop: sliderValor)
        
        if (isRedondeo){
            totalInt = Int(resultado)
            mensaje = "$\(String(totalInt))"
        } else {
            mensaje = formatearNumero(numeroBase: resultado)
        }
    }
    
    func calcularPropina(personas:Double, cuenta: Double, prop: Double) -> Double {
        var totalPersona = 0.0
        
        if (totalCuenta == 0.0 || numPersonas == 0.0 ){
            showMensaje.toggle()
        }
        else {
            totalPersona = ((cuenta*(sliderValor/100)) + cuenta) / personas
        }
        
        return totalPersona;
        
    }
    
    func formatearNumero(numeroBase: Double) -> String {
        var numeroStr: String = ""
        let formatoNumero = NumberFormatter()
        
        formatoNumero.numberStyle = .currency
        
        numeroStr = formatoNumero.string(from: NSNumber(value: numeroBase))!
        
        return numeroStr
    }
      
}
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
